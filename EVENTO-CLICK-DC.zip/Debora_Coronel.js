function cerrar(element){
    element.innerText="Logout"
    }
    
    function eliminar(element){
    element.remove()
    }